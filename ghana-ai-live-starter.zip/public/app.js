const chat = document.querySelector("#chat");
const message = document.querySelector("#message");
const send = document.querySelector("#send");
const mic = document.querySelector("#mic");
const language = document.querySelector("#language");
const modeTitle = document.querySelector("#modeTitle");
const status = document.querySelector("#status");
let mode = "Chat";
let history = JSON.parse(localStorage.getItem("ghanaAIHistory") || "[]");

function save(){ localStorage.setItem("ghanaAIHistory", JSON.stringify(history.slice(-30))); }
function addMessage(role, content, demo=false){
  document.querySelector(".welcome")?.remove();
  const row=document.createElement("div"); row.className=`msg ${role}`;
  const avatar=document.createElement("div"); avatar.className="avatar"; avatar.textContent=role==="user"?"🙂":"GH";
  const bubble=document.createElement("div"); bubble.className="bubble"; bubble.textContent=content;
  if(demo){ const b=document.createElement("div"); b.className="demo-badge"; b.textContent="Demo mode"; bubble.appendChild(b); }
  row.append(avatar,bubble); chat.appendChild(row); chat.scrollTop=chat.scrollHeight;
}
async function sendMessage(text){
  text=(text||message.value).trim(); if(!text)return;
  addMessage("user",text); history.push({role:"user",content:text}); save();
  message.value=""; message.style.height="auto"; send.disabled=true; status.textContent="Thinking…";
  try{
    const res=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message:text,language:language.value,mode,history})});
    const data=await res.json(); if(!res.ok) throw new Error(data.error||"Request failed");
    addMessage("assistant",data.reply,!!data.demo); history.push({role:"assistant",content:data.reply}); save();
    status.textContent=data.demo?"Demo interface — add API key for real AI":"Live AI";
  }catch(e){addMessage("assistant","Sorry — "+e.message);status.textContent="Connection error"}
  finally{send.disabled=false;message.focus()}
}
send.onclick=()=>sendMessage();
message.addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();sendMessage()}});
message.addEventListener("input",()=>{message.style.height="auto";message.style.height=Math.min(message.scrollHeight,140)+"px"});
document.querySelectorAll(".mode").forEach(btn=>btn.onclick=()=>{document.querySelectorAll(".mode").forEach(x=>x.classList.remove("active"));btn.classList.add("active");mode=btn.dataset.mode;modeTitle.textContent=mode});
document.querySelectorAll(".prompt").forEach(btn=>btn.onclick=()=>sendMessage(btn.dataset.prompt));
document.querySelector("#newChat").onclick=()=>{history=[];save();chat.innerHTML=`<div class="welcome"><div class="big-logo">GH</div><h1>Akwaaba to Ghana AI</h1><p>Start a fresh conversation.</p></div>`};
document.querySelector("#clear").onclick=()=>{history=[];save();chat.innerHTML=`<div class="welcome"><div class="big-logo">GH</div><h1>Akwaaba to Ghana AI</h1><p>Chat, translate and learn across Ghanaian languages.</p></div>`};
document.querySelector("#menu").onclick=()=>document.querySelector(".sidebar").classList.toggle("open");

if("webkitSpeechRecognition" in window || "SpeechRecognition" in window){
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition; const rec=new SR();
  rec.continuous=false; rec.interimResults=false;
  mic.onclick=()=>{rec.lang=language.value==="English"?"en-GH":"en-GH";rec.start();mic.textContent="⏺️"};
  rec.onresult=e=>{message.value=e.results[0][0].transcript;message.dispatchEvent(new Event("input"));};
  rec.onend=()=>mic.textContent="🎙️";
}else{mic.disabled=true;mic.title="Voice input is not supported in this browser"}
