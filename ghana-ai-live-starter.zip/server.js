import express from "express";
import dotenv from "dotenv";
import OpenAI from "openai";

dotenv.config();
const app = express();
const port = process.env.PORT || 3000;
const client = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;

app.use(express.json({ limit: "1mb" }));
app.use(express.static("public"));

const languages = ["English","Twi","Fante","Ga","Ewe","Dagbani","Dagaare","Gonja","Nzema","Kasem","Hausa"];

function demoReply({message, language, mode}) {
  const intro = {
    Chat: `Akwaaba! I’m Ghana AI. You selected ${language}.`,
    Translation: `Ghana AI translation mode is ready for ${language}.`,
    Teaching: `Ghana AI teaching mode is ready for ${language}.`
  }[mode] || "Akwaaba!";

  return `${intro}\n\nDemo mode is active because no server AI key has been added yet. You can test the interface now. Your message was: “${message}”\n\nWhen you add OPENAI_API_KEY to .env and restart the server, this becomes a real AI response.`;
}

app.post("/api/chat", async (req, res) => {
  try {
    const { message, language = "English", mode = "Chat", history = [] } = req.body || {};
    if (!message?.trim()) return res.status(400).json({ error: "Please enter a message." });
    if (!languages.includes(language)) return res.status(400).json({ error: "Unsupported language." });

    if (!client) return res.json({ reply: demoReply({message, language, mode}), demo: true });

    const system = `You are Ghana AI, a helpful multilingual assistant. Respond primarily in ${language}. Mode: ${mode}.
For Translation mode, translate the user's text accurately and briefly explain important meaning differences when useful.
For Teaching mode, teach clearly with simple examples and encourage the learner.
For Chat mode, answer naturally and helpfully.
Support Ghanaian languages respectfully. If you are uncertain about a rare-language phrase, say so rather than inventing facts.`;

    const messages = [
      { role: "system", content: system },
      ...history.slice(-10).map(x => ({ role: x.role === "assistant" ? "assistant" : "user", content: String(x.content) })),
      { role: "user", content: message }
    ];

    const response = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages,
      temperature: 0.4
    });

    res.json({ reply: response.choices?.[0]?.message?.content || "I could not generate a response." });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "AI request failed. Check your server key and connection." });
  }
});

app.listen(port, () => console.log(`Ghana AI running at http://localhost:${port}`));